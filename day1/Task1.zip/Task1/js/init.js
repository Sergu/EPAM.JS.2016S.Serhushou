var data = [];
data[0] = 120;
data[1] = "40";
data[3] = null;
data[4] = 0;
