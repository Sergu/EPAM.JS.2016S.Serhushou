function log() {
    for (var i = 0; i < data.length; i++) {
        var result;

        if (data[i] === undefined) {
            result = "не определено";
        }
        else if (data[i] === null) {
            result = "не указано";
        }
        else {
            result = data[i];
        }

        console.log("data[%s]=%s", i, result);
    }
}
