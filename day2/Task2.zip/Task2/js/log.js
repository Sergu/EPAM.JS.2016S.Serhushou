var sum = {
    count1: 0,
    count2: 0,
    count3: 0
}; 

for (var i = 0; i < data.length; i++) {
    var element = data[i];

    var getCount1 = data[i].getCount1 || getCount0;
    var getCount2 = data[i].getCount2 || getCount0;
    var getCount3 = data[i].getCount3 || getCount0;
    
    sum.count1 += getCount1.call(data[i]);
    sum.count2 += getCount2.call(data[i]);
    sum.count3 += getCount3.call(data[i]);

    function getCount0() {
        return 0;
    }
}

console.log("count1=%s", sum.count1);
console.log("count2=%s", sum.count2);
console.log("count3=%s", sum.count3);
