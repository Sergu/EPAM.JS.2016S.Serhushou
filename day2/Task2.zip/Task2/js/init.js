var data = [];

for (var i = 0; i < 5; i++) {
    var type = random(1, 3);
    var count = random(1, 10)
    var element = {
        count: count
    };

    element["getCount" + type] = function() {
        return this.count;
    };

    data[i] = element;

    console.log("type=%s, count=%s", type, count);
}
